'use client'

import { useEffect, useState } from 'react'

export default function PlanetOrbit() {
  const [rotation, setRotation] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setRotation(prev => (prev + 1) % 360)
    }, 100)
    
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative w-full h-64">
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border border-blue-500/30"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border border-blue-400/30"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full border border-blue-300/30"></div>
      
      {/* Sun */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-yellow-300 shadow-lg shadow-yellow-300/50"></div>
      
      {/* Planets */}
      <div 
        className="absolute top-1/2 left-1/2 w-3 h-3 rounded-full bg-blue-400"
        style={{ 
          transform: `rotate(${rotation}deg) translateX(24px) rotate(-${rotation}deg)` 
        }}
      ></div>
      
      <div 
        className="absolute top-1/2 left-1/2 w-4 h-4 rounded-full bg-orange-400"
        style={{ 
          transform: `rotate(${rotation * 0.8}deg) translateX(40px) rotate(-${rotation * 0.8}deg)` 
        }}
      ></div>
      
      <div 
        className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full bg-red-400"
        style={{ 
          transform: `rotate(${rotation * 0.5}deg) translateX(64px) rotate(-${rotation * 0.5}deg)` 
        }}
      ></div>
    </div>
  )
}
