'use client'

import { useState, useEffect, useRef } from 'react'

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('satellite')

  return (
    <div className="w-full bg-black/40 rounded-xl backdrop-blur-sm overflow-hidden">
      {/* Tabs */}
      <div className="flex border-b border-blue-900/50">
        <button 
          className={`px-4 py-3 text-sm font-medium ${activeTab === 'satellite' ? 'bg-blue-900/30 text-blue-300' : 'text-gray-400 hover:text-gray-300'}`}
          onClick={() => setActiveTab('satellite')}
        >
          🛰️ Satellite Orbit Viewer
        </button>
        <button 
          className={`px-4 py-3 text-sm font-medium ${activeTab === 'rover' ? 'bg-blue-900/30 text-blue-300' : 'text-gray-400 hover:text-gray-300'}`}
          onClick={() => setActiveTab('rover')}
        >
          🚀 Mars Rover Simulator
        </button>
        <button 
          className={`px-4 py-3 text-sm font-medium ${activeTab === 'iss' ? 'bg-blue-900/30 text-blue-300' : 'text-gray-400 hover:text-gray-300'}`}
          onClick={() => setActiveTab('iss')}
        >
          🏢 ISS Virtual Tour
        </button>
        <button 
          className={`px-4 py-3 text-sm font-medium ${activeTab === 'planets' ? 'bg-blue-900/30 text-blue-300' : 'text-gray-400 hover:text-gray-300'}`}
          onClick={() => setActiveTab('planets')}
        >
          🌍 Planet Comparator
        </button>
      </div>
      
      {/* Content */}
      <div className="p-6">
        {activeTab === 'satellite' && <SatelliteOrbitViewer />}
        {activeTab === 'rover' && <MarsRoverSimulator />}
        {activeTab === 'iss' && <ISSVirtualTour />}
        {activeTab === 'planets' && <PlanetComparator />}
      </div>
    </div>
  )
}

function SatelliteOrbitViewer() {
  const canvasRef = useRef(null)
  const [altitude, setAltitude] = useState(400) // km
  const [inclination, setInclination] = useState(45) // degrees
  const [speed, setSpeed] = useState(1)
  
  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    let animationFrameId
    let angle = 0
    
    const earthRadius = 100
    const satelliteSize = 4
    const orbitRadius = earthRadius + (altitude / 20)
    
    const draw = () => {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      // Draw space background
      ctx.fillStyle = '#000'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      
      // Draw some stars
      ctx.fillStyle = '#fff'
      for (let i = 0; i < 100; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height
        const size = Math.random() * 1.5
        ctx.beginPath()
        ctx.arc(x, y, size, 0, Math.PI * 2)
        ctx.fill()
      }
      
      // Center coordinates
      const centerX = canvas.width / 2
      const centerY = canvas.height / 2
      
      // Draw Earth
      const gradient = ctx.createRadialGradient(
        centerX, centerY, 0,
        centerX, centerY, earthRadius
      )
      gradient.addColorStop(0, '#1E88E5')
      gradient.addColorStop(1, '#0D47A1')
      
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(centerX, centerY, earthRadius, 0, Math.PI * 2)
      ctx.fill()
      
      // Draw orbit path
      ctx.strokeStyle = 'rgba(100, 181, 246, 0.3)'
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.ellipse(
        centerX, 
        centerY, 
        orbitRadius, 
        orbitRadius, 
        0, 
        0, 
        Math.PI * 2
      )
      ctx.stroke()
      
      // Calculate satellite position
      const inclinationRad = inclination * Math.PI / 180
      const x = centerX + orbitRadius * Math.cos(angle) 
      const y = centerY + orbitRadius * Math.sin(angle) * Math.cos(inclinationRad)
      
      // Draw satellite
      ctx.fillStyle = '#FFF'
      ctx.beginPath()
      ctx.arc(x, y, satelliteSize, 0, Math.PI * 2)
      ctx.fill()
      
      // Draw satellite trail
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)'
      ctx.lineWidth = 1
      ctx.beginPath()
      
      for (let i = 0; i < 20; i++) {
        const trailAngle = angle - (i * 0.1)
        const trailX = centerX + orbitRadius * Math.cos(trailAngle)
        const trailY = centerY + orbitRadius * Math.sin(trailAngle) * Math.cos(inclinationRad)
        
        if (i === 0) {
          ctx.moveTo(trailX, trailY)
        } else {
          ctx.lineTo(trailX, trailY)
        }
      }
      
      ctx.stroke()
      
      // Update angle for animation
      angle += 0.01 * speed
      
      // Continue animation
      animationFrameId = window.requestAnimationFrame(draw)
    }
    
    draw()
    
    return () => {
      window.cancelAnimationFrame(animationFrameId)
    }
  }, [altitude, inclination, speed])
  
  return (
    <div>
      <h3 className="text-xl font-bold mb-4 text-blue-300">Satellite Orbit Viewer</h3>
      <p className="text-gray-300 mb-6">
        Adjust the parameters to see how satellites orbit Earth at different altitudes and inclinations.
      </p>
      
      <div className="mb-6">
        <canvas 
          ref={canvasRef} 
          width={600} 
          height={400} 
          className="bg-black rounded-lg w-full h-auto"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Altitude: {altitude} km
          </label>
          <input 
            type="range" 
            min="200" 
            max="1000" 
            value={altitude} 
            onChange={(e) => setAltitude(parseInt(e.target.value))}
            className="w-full"
          />
          <p className="text-xs text-gray-400 mt-1">
            Low Earth Orbit: 200-1000 km
          </p>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Inclination: {inclination}°
          </label>
          <input 
            type="range" 
            min="0" 
            max="90" 
            value={inclination} 
            onChange={(e) => setInclination(parseInt(e.target.value))}
            className="w-full"
          />
          <p className="text-xs text-gray-400 mt-1">
            0° = Equatorial, 90° = Polar
          </p>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Animation Speed
          </label>
          <input 
            type="range" 
            min="0.5" 
            max="3" 
            step="0.5"
            value={speed} 
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            className="w-full"
          />
        </div>
      </div>
    </div>
  )
}

function MarsRoverSimulator() {
  const canvasRef = useRef(null)
  const [roverX, setRoverX] = useState(300)
  const [roverY, setRoverY] = useState(200)
  const [roverDirection, setRoverDirection] = useState(0) // 0 = right, 1 = down, 2 = left, 3 = up
  
  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    
    // Draw Mars terrain
    ctx.fillStyle = '#B71C1C'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    
    // Draw some craters
    for (let i = 0; i < 20; i++) {
      const x = Math.random() * canvas.width
      const y = Math.random() * canvas.height
      const radius = 5 + Math.random() * 20
      
      const gradient = ctx.createRadialGradient(
        x, y, 0,
        x, y, radius
      )
      gradient.addColorStop(0, '#8D1D1D')
      gradient.addColorStop(1, '#B71C1C')
      
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)
      ctx.fill()
    }
    
    // Draw some rocks
    for (let i = 0; i < 30; i++) {
      const x = Math.random() * canvas.width
      const y = Math.random() * canvas.height
      const size = 3 + Math.random() * 8
      
      ctx.fillStyle = '#6D1010'
      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }
    
    // Draw rover
    ctx.save()
    ctx.translate(roverX, roverY)
    ctx.rotate(roverDirection * Math.PI / 2)
    
    // Rover body
    ctx.fillStyle = '#DDD'
    ctx.fillRect(-15, -10, 30, 20)
    
    // Rover wheels
    ctx.fillStyle = '#333'
    ctx.fillRect(-18, -12, 6, 5)
    ctx.fillRect(-18, 7, 6, 5)
    ctx.fillRect(12, -12, 6, 5)
    ctx.fillRect(12, 7, 6, 5)
    
    // Rover solar panel
    ctx.fillStyle = '#1976D2'
    ctx.fillRect(-10, -15, 20, 5)
    
    // Rover camera
    ctx.fillStyle = '#555'
    ctx.beginPath()
    ctx.arc(10, 0, 5, 0, Math.PI * 2)
    ctx.fill()
    
    ctx.restore()
    
  }, [roverX, roverY, roverDirection])
  
  const moveRover = (direction) => {
    setRoverDirection(direction)
    
    switch(direction) {
      case 0: // Right
        setRoverX(prev => Math.min(prev + 20, 580))
        break
      case 1: // Down
        setRoverY(prev => Math.min(prev + 20, 380))
        break
      case 2: // Left
        setRoverX(prev => Math.max(prev - 20, 20))
        break
      case 3: // Up
        setRoverY(prev => Math.max(prev - 20, 20))
        break
    }
  }
  
  return (
    <div>
      <h3 className="text-xl font-bold mb-4 text-red-300">Mars Rover Simulator</h3>
      <p className="text-gray-300 mb-6">
        Control a virtual rover on the Martian surface. Use the directional buttons to navigate.
      </p>
      
      <div className="mb-6">
        <canvas 
          ref={canvasRef} 
          width={600} 
          height={400} 
          className="bg-red-900 rounded-lg w-full h-auto"
        />
      </div>
      
      <div className="flex justify-center">
        <div className="grid grid-cols-3 gap-2">
          <div></div>
          <button 
            className="bg-gray-800 hover:bg-gray-700 text-white p-3 rounded"
            onClick={() => moveRover(3)}
          >
            ↑
          </button>
          <div></div>
          
          <button 
            className="bg-gray-800 hover:bg-gray-700 text-white p-3 rounded"
            onClick={() => moveRover(2)}
          >
            ←
          </button>
          <div></div>
          <button 
            className="bg-gray-800 hover:bg-gray-700 text-white p-3 rounded"
            onClick={() => moveRover(0)}
          >
            →
          </button>
          
          <div></div>
          <button 
            className="bg-gray-800 hover:bg-gray-700 text-white p-3 rounded"
            onClick={() => moveRover(1)}
          >
            ↓
          </button>
          <div></div>
        </div>
      </div>
    </div>
  )
}

function ISSVirtualTour() {
  const [currentModule, setCurrentModule] = useState('node1')
  
  const modules = {
    node1: {
      name: 'Unity (Node 1)',
      description: 'The first U.S. module of the ISS, connecting the Russian and American segments.',
      connections: ['zarya', 'node3', 'destiny']
    },
    zarya: {
      name: 'Zarya (FGB)',
      description: 'The first module of the ISS, providing initial power and propulsion.',
      connections: ['node1', 'zvezda']
    },
    zvezda: {
      name: 'Zvezda Service Module',
      description: 'The Russian core module that provides life support systems and living quarters.',
      connections: ['zarya', 'progress']
    },
    destiny: {
      name: 'Destiny Laboratory',
      description: 'The primary research laboratory for U.S. experiments.',
      connections: ['node1', 'node2']
    },
    node2: {
      name: 'Harmony (Node 2)',
      description: 'Connects the European and Japanese laboratories to the rest of the station.',
      connections: ['destiny', 'columbus', 'kibo']
    },
    node3: {
      name: 'Tranquility (Node 3)',
      description: 'Houses life support systems and exercise equipment.',
      connections: ['node1', 'cupola']
    },
    columbus: {
      name: 'Columbus Laboratory',
      description: 'The European Space Agency\'s primary research laboratory.',
      connections: ['node2']
    },
    kibo: {
      name: 'Kibo Japanese Laboratory',
      description: 'Japan\'s science module, the largest on the station.',
      connections: ['node2']
    },
    cupola: {
      name: 'Cupola Observation Module',
      description: 'A dome-shaped module with seven windows for Earth observation.',
      connections: ['node3']
    },
    progress: {
      name: 'Progress Supply Ship',
      description: 'Russian cargo spacecraft that delivers supplies to the ISS.',
      connections: ['zvezda']
    }
  }
  
  return (
    <div>
      <h3 className="text-xl font-bold mb-4 text-indigo-300">ISS Virtual Tour</h3>
      <p className="text-gray-300 mb-6">
        Explore the International Space Station by navigating between modules. Click on connected modules to move through the station.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <div className="bg-black/50 p-6 rounded-lg h-full">
            <h4 className="text-lg font-bold mb-2 text-white">{modules[currentModule].name}</h4>
            <p className="text-gray-300 mb-4">{modules[currentModule].description}</p>
            
            <div className="mt-6">
              <h5 className="text-sm font-medium text-indigo-300 mb-2">CONNECTED MODULES:</h5>
              <div className="flex flex-wrap gap-2">
                {modules[currentModule].connections.map(module => (
                  <button
                    key={module}
                    className="px-3 py-1 bg-indigo-900/30 hover:bg-indigo-900/50 rounded text-sm text-white transition-colors"
                    onClick={() => setCurrentModule(module)}
                  >
                    {modules[module].name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-black/30 rounded-lg overflow-hidden">
          <div className="relative aspect-video">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">🛰️</div>
                <div className="text-xl font-bold text-white">{modules[currentModule].name}</div>
              </div>
            </div>
          </div>
          
          <div className="p-4">
            <div className="w-full bg-black/50 rounded-lg p-4">
              <div className="text-xs text-gray-400 mb-2">ISS MODULE MAP</div>
              <div className="flex flex-wrap gap-1 justify-center">
                {Object.keys(modules).map(module => (
                  <div
                    key={module}
                    className={`w-3 h-3 rounded-full cursor-pointer ${
                      module === currentModule 
                        ? 'bg-indigo-500' 
                        : modules[currentModule].connections.includes(module)
                          ? 'bg-indigo-800'
                          : 'bg-gray-700'
                    }`}
                    onClick={() => {
                      if (module === currentModule || modules[currentModule].connections.includes(module)) {
                        setCurrentModule(module)
                      }
                    }}
                    title={modules[module].name}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function PlanetComparator() {
  const [selectedPlanets, setSelectedPlanets] = useState(['earth', 'mars'])
  const [comparisonType, setComparisonType] = useState('size')
  
  const planets = {
    mercury: {
      name: 'Mercury',
      diameter: 4879, // km
      distance: 57.9, // million km
      day: 58.6, // Earth days
      year: 88, // Earth days
      gravity: 3.7, // m/s²
      temperature: 167, // °C (average)
      moons: 0,
      color: '#A5A5A5'
    },
    venus: {
      name: 'Venus',
      diameter: 12104,
      distance: 108.2,
      day: 243,
      year: 225,
      gravity: 8.9,
      temperature: 464,
      moons: 0,
      color: '#E6B87C'
    },
    earth: {
      name: 'Earth',
      diameter: 12756,
      distance: 149.6,
      day: 1,
      year: 365.25,
      gravity: 9.8,
      temperature: 15,
      moons: 1,
      color: '#4B7BBE'
    },
    mars: {
      name: 'Mars',
      diameter: 6792,
      distance: 227.9,
      day: 1.03,
      year: 687,
      gravity: 3.7,
      temperature: -65,
      moons: 2,
      color: '#C1440E'
    },
    jupiter: {
      name: 'Jupiter',
      diameter: 142984,
      distance: 778.6,
      day: 0.41,
      year: 4333,
      gravity: 23.1,
      temperature: -110,
      moons: 79,
      color: '#D8CA9D'
    },
    saturn: {
      name: 'Saturn',
      diameter: 120536,
      distance: 1433.5,
      day: 0.45,
      year: 10759,
      gravity: 9.0,
      temperature: -140,
      moons: 82,
      color: '#E6C88A'
    },
    uranus: {
      name: 'Uranus',
      diameter: 51118,
      distance: 2872.5,
      day: 0.72,
      year: 30687,
      gravity: 8.7,
      temperature: -195,
      moons: 27,
      color: '#9BBCD1'
    },
    neptune: {
      name: 'Neptune',
      diameter: 49528,
      distance: 4495.1,
      day: 0.67,
      year: 60190,
      gravity: 11.0,
      temperature: -200,
      moons: 14,
      color: '#3E54E8'
    }
  }
  
  const handlePlanetToggle = (planet) => {
    if (selectedPlanets.includes(planet)) {
      if (selectedPlanets.length > 1) {
        setSelectedPlanets(selectedPlanets.filter(p => p !== planet))
      }
    } else {
      if (selectedPlanets.length < 3) {
        setSelectedPlanets([...selectedPlanets, planet])
      }
    }
  }
  
  const getComparisonData = () => {
    switch (comparisonType) {
      case 'size':
        return {
          property: 'diameter',
          unit: 'km',
          label: 'Diameter',
          description: 'The diameter of the planet at its equator.'
        }
      case 'distance':
        return {
          property: 'distance',
          unit: 'million km',
          label: 'Distance from Sun',
          description: 'The average distance from the planet to the Sun.'
        }
      case 'day':
        return {
          property: 'day',
          unit: 'Earth days',
          label: 'Day Length',
          description: 'The time it takes for the planet to rotate once on its axis.'
        }
      case 'year':
        return {
          property: 'year',
          unit: 'Earth days',
          label: 'Year Length',
          description: 'The time it takes for the planet to orbit the Sun once.'
        }
      case 'gravity':
        return {
          property: 'gravity',
          unit: 'm/s²',
          label: 'Surface Gravity',
          description: 'The gravitational acceleration on the planet\'s surface.'
        }
      case 'temperature':
        return {
          property: 'temperature',
          unit: '°C',
          label: 'Average Temperature',
          description: 'The average surface temperature of the planet.'
        }
      case 'moons':
        return {
          property: 'moons',
          unit: '',
          label: 'Number of Moons',
          description: 'The number of natural satellites orbiting the planet.'
        }
    }
  }
  
  const comparisonData = getComparisonData()
  const maxValue = Math.max(...Object.values(planets).map(planet => planet[comparisonData.property]))
  
  return (
    <div>
      <h3 className="text-xl font-bold mb-4 text-purple-300">Planet Comparator</h3>
      <p className="text-gray-300 mb-6">
        Compare different features of planets in our solar system. Select up to three planets and choose a comparison type.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div>
          <h4 className="text-sm font-medium text-gray-300 mb-3">SELECT PLANETS (UP TO 3):</h4>
          <div className="grid grid-cols-4 gap-2">
            {Object.keys(planets).map(planet => (
              <button
                key={planet}
                className={`p-2 rounded text-xs text-center transition-colors ${
                  selectedPlanets.includes(planet)
                    ? 'bg-purple-900 text-white'
                    : 'bg-black/30 text-gray-400 hover:bg-black/50'
                }`}
                onClick={() => handlePlanetToggle(planet)}
              >
                {planets[planet].name}
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="text-sm font-medium text-gray-300 mb-3">COMPARISON TYPE:</h4>
          <div className="grid grid-cols-2 gap-2">
            <button
              className={`p-2 rounded text-xs text-center transition-colors ${
                comparisonType === 'size' ? 'bg-purple-900 text-white' : 'bg-black/30 text-gray-400 hover:bg-black/50'
              }`}
              onClick={() => setComparisonType('size')}
            >
              Size
            </button>
            <button
              className={`p-2 rounded text-xs text-center transition-colors ${
                comparisonType === 'distance' ? 'bg-purple-900 text-white' : 'bg-black/30 text-gray-400 hover:bg-black/50'
              }`}
              onClick={() => setComparisonType('distance')}
            >
              Distance from Sun
            </button>
            <button
              className={`p-2 rounded text-xs text-center transition-colors ${
                comparisonType === 'day' ? 'bg-purple-900 text-white' : 'bg-black/30 text-gray-400 hover:bg-black/50'
              }`}
              onClick={() => setComparisonType('day')}
            >
              Day Length
            </button>
            <button
              className={`p-2 rounded text-xs text-center transition-colors ${
                comparisonType === 'year' ? 'bg-purple-900 text-white' : 'bg-black/30 text-gray-400 hover:bg-black/50'
              }`}
              onClick={() => setComparisonType('year')}
            >
              Year Length
            </button>
            <button
              className={`p-2 rounded text-xs text-center transition-colors ${
                comparisonType === 'gravity' ? 'bg-purple-900 text-white' : 'bg-black/30 text-gray-400 hover:bg-black/50'
              }`}
              onClick={() => setComparisonType('gravity')}
            >
              Surface Gravity
            </button>
            <button
              className={`p-2 rounded text-xs text-center transition-colors ${
                comparisonType === 'temperature' ? 'bg-purple-900 text-white' : 'bg-black/30 text-gray-400 hover:bg-black/50'
              }`}
              onClick={() => setComparisonType('temperature')}
            >
              Temperature
            </button>
            <button
              className={`p-2 rounded text-xs text-center transition-colors ${
                comparisonType === 'moons' ? 'bg-purple-900 text-white' : 'bg-black/30 text-gray-400 hover:bg-black/50'
              }`}
              onClick={() => setComparisonType('moons')}
            >
              Number of Moons
            </button>
          </div>
        </div>
      </div>
      
      <div className="bg-black/30 p-6 rounded-lg">
        <h4 className="text-lg font-bold mb-2 text-white">{comparisonData.label} Comparison</h4>
        <p className="text-gray-400 text-sm mb-6">{comparisonData.description}</p>
        
        <div className="space-y-6">
          {selectedPlanets.map(planet => {
            const value = planets[planet][comparisonData.property]
            const percentage = (value / maxValue) * 100
            
            return (
              <div key={planet}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-white">{planets[planet].name}</span>
                  <span className="text-sm text-gray-300">
                    {value.toLocaleString()} {comparisonData.unit}
                  </span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-4">
                  <div 
                    className="h-4 rounded-full" 
                    style={{
                      width: `${percentage}%`,
                      backgroundColor: planets[planet].color
                    }}
                  ></div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
