'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Navbar from '@/components/navigation/Navbar'

export default function SpaceHistory() {
  // Force dark mode
  useEffect(() => {
    document.documentElement.classList.add('dark')
  }, [])

  const [activeEra, setActiveEra] = useState('ancient')

  const timelineEras = [
    { id: 'ancient', name: 'Ancient Astronomy', years: '3000 BCE - 500 CE' },
    { id: 'renaissance', name: 'Renaissance', years: '1500s - 1700s' },
    { id: 'early-modern', name: 'Early Modern', years: '1800s - 1950s' },
    { id: 'space-race', name: 'Space Race', years: '1950s - 1970s' },
    { id: 'space-shuttle', name: 'Space Shuttle Era', years: '1980s - 2011' },
    { id: 'modern', name: 'Modern Era', years: '2011 - Present' },
  ]

  const timelineEvents = {
    'ancient': [
      { year: '3000 BCE', event: 'Ancient Egyptians and Babylonians track celestial objects', description: 'Early civilizations began mapping the stars and planets, using them for navigation and creating calendars.' },
      { year: '585 BCE', event: 'Thales of Miletus predicts a solar eclipse', description: 'One of the earliest recorded scientific predictions of an astronomical event.' },
      { year: '350 BCE', event: 'Aristotle argues for a spherical Earth', description: 'Based on observations of lunar eclipses and the changing positions of stars when traveling north or south.' },
      { year: '240 BCE', event: 'Eratosthenes calculates Earth\'s circumference', description: 'Using the angle of shadows at different locations, he calculated Earth\'s size with remarkable accuracy.' },
      { year: '150 CE', event: 'Ptolemy publishes the Almagest', description: 'A comprehensive astronomical treatise that became the definitive work on astronomy for over a millennium.' },
    ],
    'renaissance': [
      { year: '1543', event: 'Copernicus publishes heliocentric model', description: 'On the Revolutions of the Celestial Spheres proposed that the Earth revolves around the Sun.' },
      { year: '1609', event: 'Galileo builds his first telescope', description: 'Using his telescope, Galileo observed Jupiter\'s moons, providing evidence for the Copernican model.' },
      { year: '1610', event: 'Galileo discovers Jupiter\'s four largest moons', description: 'The observation of these moons challenged the geocentric model of the universe.' },
      { year: '1687', event: 'Newton publishes Principia Mathematica', description: 'Established the laws of motion and universal gravitation, explaining planetary orbits.' },
      { year: '1705', event: 'Halley predicts the return of a comet', description: 'Edmund Halley calculated that comets observed in 1531, 1607, and 1682 were the same object, predicting its return in 1758.' },
    ],
    'early-modern': [
      { year: '1838', event: 'First stellar parallax measurement', description: 'Friedrich Bessel measured the distance to 61 Cygni, the first direct measurement of a star\'s distance.' },
      { year: '1903', event: 'Wright brothers achieve powered flight', description: 'The first controlled, sustained flight of a powered, heavier-than-air aircraft.' },
      { year: '1926', event: 'Goddard launches first liquid-fueled rocket', description: 'Robert Goddard\'s rocket flew for just 2.5 seconds but demonstrated the principle that would later enable spaceflight.' },
      { year: '1942', event: 'V-2 rocket first successful launch', description: 'The world\'s first long-range ballistic missile, later used as the foundation for early space rockets.' },
      { year: '1947', event: 'Sound barrier broken by Chuck Yeager', description: 'The Bell X-1 aircraft exceeded the speed of sound, a crucial step toward space travel.' },
    ],
    'space-race': [
      { year: '1957', event: 'Sputnik 1 launched by Soviet Union', description: 'The first artificial satellite to orbit Earth, marking the beginning of the Space Age.' },
      { year: '1961', event: 'Yuri Gagarin becomes first human in space', description: 'Completed one orbit around Earth in Vostok 1, becoming the first human to journey into outer space.' },
      { year: '1962', event: 'John Glenn orbits Earth', description: 'First American to orbit Earth, circling the planet three times in Friendship 7.' },
      { year: '1969', event: 'Apollo 11 Moon landing', description: 'Neil Armstrong and Buzz Aldrin became the first humans to walk on the lunar surface.' },
      { year: '1971', event: 'Salyut 1, first space station launched', description: 'The Soviet Union launched the world\'s first space station, beginning the era of long-duration spaceflight.' },
    ],
    'space-shuttle': [
      { year: '1981', event: 'First Space Shuttle launch (Columbia)', description: 'The first reusable spacecraft, revolutionizing space transportation.' },
      { year: '1986', event: 'Challenger disaster', description: 'Space Shuttle Challenger broke apart 73 seconds into its flight, killing all seven crew members.' },
      { year: '1990', event: 'Hubble Space Telescope deployed', description: 'Revolutionized astronomy with its deep, detailed views of the universe.' },
      { year: '1998', event: 'International Space Station construction begins', description: 'The largest modular space station and the largest artificial object in Earth orbit.' },
      { year: '2003', event: 'Columbia disaster', description: 'Space Shuttle Columbia disintegrated during re-entry, killing all seven astronauts aboard.' },
    ],
    'modern': [
      { year: '2011', event: 'Final Space Shuttle mission', description: 'Atlantis completed the final mission of the Space Shuttle program after 30 years of service.' },
      { year: '2012', event: 'Curiosity rover lands on Mars', description: 'The most sophisticated Mars rover to date, designed to assess whether Mars ever had an environment able to support life.' },
      { year: '2015', event: 'New Horizons reaches Pluto', description: 'Completed the first flyby of Pluto, providing detailed images of the dwarf planet.' },
      { year: '2020', event: 'SpaceX sends astronauts to ISS', description: 'First commercial company to send humans to the International Space Station.' },
      { year: '2021', event: 'Perseverance rover lands on Mars', description: 'Carrying the Ingenuity helicopter, the first aircraft to fly on another planet.' },
    ],
  }

  return (
    <main className="stars-bg min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="space-title">History of Space Exploration</h1>
          <p className="space-subtitle max-w-3xl mx-auto">
            From ancient stargazers to modern astronauts, discover humanity's journey to the stars.
          </p>
        </div>
      </section>
      
      {/* Interactive Timeline */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300 text-center">Interactive Timeline</h2>
          
          {/* Era Selection */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {timelineEras.map((era) => (
              <button
                key={era.id}
                className={`px-4 py-2 rounded-full transition-all ${
                  activeEra === era.id 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-black/30 text-gray-300 hover:bg-black/50'
                }`}
                onClick={() => setActiveEra(era.id)}
              >
                <span className="block text-sm font-medium">{era.name}</span>
                <span className="block text-xs opacity-70">{era.years}</span>
              </button>
            ))}
          </div>
          
          {/* Timeline Events */}
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-1 bg-blue-500/30 transform md:translate-x-[-50%]"></div>
            
            {/* Events */}
            <div className="space-y-12">
              {timelineEvents[activeEra].map((item, index) => (
                <div key={index} className={`relative flex flex-col md:flex-row gap-8 ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}>
                  {/* Timeline Dot */}
                  <div className="absolute left-[-8px] md:left-1/2 top-0 w-4 h-4 rounded-full bg-blue-500 transform md:translate-x-[-50%] z-10"></div>
                  
                  {/* Date */}
                  <div className="md:w-1/2 flex justify-center md:justify-end items-start">
                    <div className="bg-blue-900/30 px-4 py-2 rounded-lg">
                      <span className="text-xl font-bold text-blue-300">{item.year}</span>
                    </div>
                  </div>
                  
                  {/* Content */}
                  <div className="md:w-1/2 bg-black/30 p-6 rounded-xl backdrop-blur-sm">
                    <h3 className="text-xl font-bold mb-2 text-white">{item.event}</h3>
                    <p className="text-gray-300">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Key Milestones */}
      <section className="py-16 px-4 bg-black/30">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300">Key Milestones in Space Exploration</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Ancient & Medieval Views */}
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-yellow-300">Ancient & Medieval Views</h3>
              <p className="text-gray-300 mb-4">
                For thousands of years, humans observed the night sky with the naked eye, 
                developing sophisticated models of celestial mechanics. Ancient civilizations 
                like the Babylonians, Egyptians, and Greeks meticulously tracked the movements 
                of stars and planets.
              </p>
              <p className="text-gray-300">
                The geocentric model, which placed Earth at the center of the universe, dominated 
                astronomical thinking until the Renaissance. Astronomers like Ptolemy created complex 
                mathematical models to explain the observed movements of celestial bodies.
              </p>
            </div>
            
            {/* Early Aviation & Rocketry */}
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-blue-300">Early Aviation & Rocketry</h3>
              <p className="text-gray-300 mb-4">
                The dream of flight became reality in the early 20th century. The Wright brothers' 
                successful powered flight in 1903 marked the beginning of aviation, while theoretical 
                work by Konstantin Tsiolkovsky laid the mathematical foundation for spaceflight.
              </p>
              <p className="text-gray-300">
                Robert Goddard's experiments with liquid-fueled rockets in the 1920s and 1930s 
                demonstrated the principles that would later enable space travel. During World War II, 
                German scientists developed the V-2 rocket, the first ballistic missile and the 
                predecessor to the rockets that would later carry humans to space.
              </p>
            </div>
            
            {/* Spaceflight Evolution */}
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-purple-300">Spaceflight Evolution</h3>
              <p className="text-gray-300 mb-4">
                The Space Age began in 1957 with the launch of Sputnik 1 by the Soviet Union. 
                This was quickly followed by the first human in space, Yuri Gagarin, in 1961. 
                The United States responded with its own space program, culminating in the 
                Apollo Moon landings between 1969 and 1972.
              </p>
              <p className="text-gray-300">
                The development of space stations, beginning with Salyut 1 in 1971 and continuing 
                with Skylab, Mir, and the International Space Station, enabled long-duration human 
                presence in space. The Space Shuttle program (1981-2011) introduced reusable spacecraft, 
                while robotic missions have explored every planet in our solar system.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* 20th & 21st Century */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300">20th & 21st Century Space Exploration</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-black/30 rounded-xl p-8 backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-4 text-red-300">The Cold War Space Race</h3>
              <p className="text-gray-300 mb-4">
                The Space Race between the United States and the Soviet Union was a period of intense 
                competition that drove rapid technological advancement. Following the Soviet launch of 
                Sputnik 1 in 1957, both nations invested heavily in their space programs as a demonstration 
                of technological and ideological superiority.
              </p>
              <p className="text-gray-300 mb-4">
                The Soviet Union achieved early victories, including the first satellite, the first human 
                in space (Yuri Gagarin), and the first spacewalk. The United States responded with the 
                Mercury, Gemini, and Apollo programs, ultimately achieving the first human Moon landing 
                with Apollo 11 in 1969.
              </p>
              <p className="text-gray-300">
                The competition eventually gave way to cooperation, with the Apollo-Soyuz Test Project 
                in 1975 symbolizing a thaw in Cold War tensions. This collaborative spirit would later 
                inform the development of the International Space Station.
              </p>
              <div className="mt-6">
                <Link href="/space-race" className="nav-button inline-block">
                  Explore the Space Race
                </Link>
              </div>
            </div>
            
            <div className="bg-black/30 rounded-xl p-8 backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-4 text-blue-300">Modern Space Exploration</h3>
              <p className="text-gray-300 mb-4">
                The 21st century has seen a renaissance in space exploration, characterized by international 
                cooperation and the emergence of private space companies. The International Space Station, 
                a collaboration between five space agencies, has maintained continuous human presence in 
                space since 2000.
              </p>
              <p className="text-gray-300 mb-4">
                Robotic missions have revolutionized our understanding of the solar system. The Mars rovers 
                (Spirit, Opportunity, Curiosity, and Perseverance) have explored the Martian surface, while 
                probes like Cassini-Huygens, New Horizons, and Juno have provided unprecedented views of 
                Saturn, Pluto, and Jupiter respectively.
              </p>
              <p className="text-gray-300">
                Private companies like SpaceX, Blue Origin, and Virgin Galactic are making space more 
                accessible through innovations like reusable rockets and space tourism. Meanwhile, space 
                agencies are planning ambitious missions to return humans to the Moon and eventually send 
                them to Mars.
              </p>
              <div className="mt-6">
                <Link href="/modern-space" className="nav-button inline-block">
                  Discover Modern Space Tech
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-12 px-4 bg-black/50">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">© 2025 Cosmic Explorer | Interactive Space Exploration Website</p>
          <p className="text-gray-500 text-sm mt-2">Developed with Next.js and TailwindCSS</p>
        </div>
      </footer>
    </main>
  )
}
