'use client'

import { useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/navigation/Navbar'

export default function ModernSpace() {
  // Force dark mode
  useEffect(() => {
    document.documentElement.classList.add('dark')
  }, [])

  const technologies = [
    {
      name: "Reusable Rockets",
      description: "Spacecraft designed to return to Earth intact and be launched again, dramatically reducing the cost of access to space.",
      examples: ["SpaceX Falcon 9", "Blue Origin New Shepard", "SpaceX Starship"],
      icon: "🚀"
    },
    {
      name: "Satellite Constellations",
      description: "Networks of satellites working together to provide global coverage for communications, Earth observation, and more.",
      examples: ["Starlink", "OneWeb", "Planet Labs"],
      icon: "🛰️"
    },
    {
      name: "Space Stations",
      description: "Habitable artificial satellites designed for long-term occupation in low Earth orbit, serving as scientific laboratories and proving grounds for deep space missions.",
      examples: ["International Space Station", "Tiangong Space Station", "Planned Lunar Gateway"],
      icon: "🏢"
    },
    {
      name: "Mars Exploration",
      description: "Robotic missions to study the Red Planet's geology, climate, and potential for past or present life, paving the way for future human missions.",
      examples: ["Perseverance Rover", "Ingenuity Helicopter", "Mars Sample Return Mission"],
      icon: "🔴"
    },
    {
      name: "Space Telescopes",
      description: "Observatories placed in space to observe distant planets, stars, and galaxies without atmospheric interference.",
      examples: ["James Webb Space Telescope", "Hubble Space Telescope", "Nancy Grace Roman Space Telescope"],
      icon: "🔭"
    },
    {
      name: "Private Spaceflight",
      description: "Commercial companies developing spacecraft for various purposes, from satellite launches to space tourism.",
      examples: ["SpaceX", "Blue Origin", "Virgin Galactic"],
      icon: "💼"
    }
  ]

  const futureTrends = [
    {
      name: "Space Colonization",
      description: "Establishing permanent human settlements beyond Earth, beginning with the Moon and Mars.",
      timeline: "2030s-2050s",
      challenges: ["Radiation protection", "Life support systems", "Psychological effects of isolation"],
      color: "bg-red-900/30"
    },
    {
      name: "Asteroid Mining",
      description: "Extracting valuable resources from near-Earth asteroids, potentially worth trillions of dollars.",
      timeline: "2030s-2040s",
      challenges: ["Autonomous extraction technology", "Return logistics", "Legal frameworks"],
      color: "bg-yellow-900/30"
    },
    {
      name: "Artificial Gravity",
      description: "Creating gravity-like conditions in space to mitigate the health effects of long-term microgravity exposure.",
      timeline: "2040s-2050s",
      challenges: ["Engineering rotating habitats", "Transition zones", "Human adaptation studies"],
      color: "bg-blue-900/30"
    },
    {
      name: "Advanced Propulsion",
      description: "New propulsion technologies to reduce travel time within the solar system and potentially enable interstellar missions.",
      timeline: "2030s-2060s",
      challenges: ["Nuclear propulsion safety", "Antimatter production", "Energy requirements"],
      color: "bg-purple-900/30"
    },
    {
      name: "AI in Space Exploration",
      description: "Autonomous systems and artificial intelligence for spacecraft operation, scientific discovery, and resource utilization.",
      timeline: "2020s-2030s",
      challenges: ["Radiation-hardened computing", "Autonomous decision-making", "Earth-independent operations"],
      color: "bg-green-900/30"
    },
    {
      name: "Space-Based Solar Power",
      description: "Collecting solar energy in space and transmitting it to Earth, providing clean, continuous power regardless of weather or time of day.",
      timeline: "2040s-2060s",
      challenges: ["Wireless power transmission", "Assembly of large structures in space", "Economic viability"],
      color: "bg-orange-900/30"
    }
  ]

  return (
    <main className="stars-bg min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="space-title">21st-Century Space Technology</h1>
          <p className="space-subtitle max-w-3xl mx-auto">
            Exploring the cutting-edge innovations and future trends shaping humanity's journey to the stars.
          </p>
        </div>
      </section>
      
      {/* Current Advancements */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300 text-center">Current Advancements</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {technologies.map((tech, index) => (
              <div key={index} className="bg-black/30 rounded-xl overflow-hidden planet-card">
                <div className="p-6">
                  <div className="text-4xl mb-4">{tech.icon}</div>
                  <h3 className="text-xl font-bold mb-3 text-blue-300">{tech.name}</h3>
                  <p className="text-gray-300 mb-4">{tech.description}</p>
                  <div>
                    <h4 className="text-sm font-semibold text-blue-200 mb-2">EXAMPLES:</h4>
                    <ul className="space-y-1">
                      {tech.examples.map((example, i) => (
                        <li key={i} className="text-gray-400 text-sm flex items-start">
                          <span className="text-blue-400 mr-2">•</span>
                          {example}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Rockets and Spacecraft */}
      <section className="py-16 px-4 bg-black/30">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300">Rockets & Spacecraft</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-black/50 rounded-xl p-8 backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-4 text-orange-300">Reusable Launch Vehicles</h3>
              <p className="text-gray-300 mb-4">
                One of the most significant advancements in modern space technology is the development of reusable 
                launch vehicles. Traditional rockets were discarded after a single use, making spaceflight extremely 
                expensive. Companies like SpaceX have revolutionized the industry by creating rockets that can land 
                and be reused multiple times.
              </p>
              <p className="text-gray-300 mb-4">
                The SpaceX Falcon 9 has demonstrated this capability with numerous successful landings and reflights, 
                reducing launch costs by as much as 30%. Blue Origin's New Shepard has also achieved reusability for 
                suborbital flights, while the company develops the larger New Glenn for orbital missions.
              </p>
              <p className="text-gray-300">
                The next generation of reusable vehicles, like SpaceX's Starship, aims to be fully reusable—including 
                both the booster and the spacecraft—potentially reducing costs even further and enabling missions to 
                the Moon, Mars, and beyond.
              </p>
            </div>
            
            <div className="bg-black/50 rounded-xl p-8 backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-4 text-blue-300">Satellites & Space Stations</h3>
              <p className="text-gray-300 mb-4">
                Modern satellites have evolved dramatically from their early predecessors. Today's satellites are smaller, 
                more capable, and often deployed in constellations. CubeSats—small, standardized satellites often built by 
                universities and small companies—have democratized access to space.
              </p>
              <p className="text-gray-300 mb-4">
                Mega-constellations like SpaceX's Starlink and OneWeb are deploying thousands of satellites to provide 
                global internet coverage. Earth observation constellations like Planet Labs offer daily imaging of the 
                entire Earth's surface, revolutionizing fields from agriculture to disaster response.
              </p>
              <p className="text-gray-300">
                The International Space Station continues to serve as humanity's outpost in low Earth orbit, while China's 
                Tiangong Space Station represents a new player in space station development. Looking forward, NASA's Lunar 
                Gateway will establish a permanent presence in lunar orbit, supporting Artemis program missions to the Moon's 
                surface.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Mars and Deep Space */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300">Mars & Deep Space Exploration</h2>
          
          <div className="bg-black/30 rounded-xl p-8 backdrop-blur-sm">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-bold mb-4 text-red-300">Mars Missions</h3>
                <p className="text-gray-300 mb-4">
                  Mars exploration has seen remarkable progress in the 21st century. NASA's Perseverance rover, 
                  which landed in 2021, is searching for signs of ancient life and collecting samples for eventual 
                  return to Earth. Its companion, the Ingenuity helicopter, became the first aircraft to achieve 
                  powered, controlled flight on another planet.
                </p>
                <p className="text-gray-300">
                  These missions build on the success of previous rovers like Curiosity, Opportunity, and Spirit, 
                  which have collectively transformed our understanding of the Red Planet. The upcoming Mars Sample 
                  Return mission will bring Martian material back to Earth for detailed analysis, while various space 
                  agencies and private companies are developing plans for human missions to Mars in the 2030s.
                </p>
              </div>
              
              <div>
                <h3 className="text-2xl font-bold mb-4 text-purple-300">Deep Space Exploration</h3>
                <p className="text-gray-300 mb-4">
                  Beyond Mars, robotic missions continue to explore the outer solar system. The James Webb Space 
                  Telescope, launched in 2021, is providing unprecedented views of distant galaxies, exoplanets, 
                  and the early universe from its position at the L2 Lagrange point.
                </p>
                <p className="text-gray-300">
                  Missions like New Horizons, which completed the first flyby of Pluto in 2015 and is now exploring 
                  the Kuiper Belt, and the Juno spacecraft orbiting Jupiter, continue to expand our knowledge of the 
                  outer planets. The European Space Agency's JUICE mission and NASA's Europa Clipper will soon explore 
                  Jupiter's icy moons, searching for subsurface oceans that could potentially harbor life.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Future Trends */}
      <section className="py-16 px-4 bg-black/30">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300 text-center">Future Trends</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {futureTrends.map((trend, index) => (
              <div key={index} className={`rounded-xl overflow-hidden planet-card ${trend.color}`}>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 text-white">{trend.name}</h3>
                  <p className="text-sm text-blue-200 mb-4">Estimated Timeline: {trend.timeline}</p>
                  <p className="text-gray-300 mb-4">{trend.description}</p>
                  <div>
                    <h4 className="text-sm font-semibold text-blue-200 mb-2">KEY CHALLENGES:</h4>
                    <ul className="space-y-1">
                      {trend.challenges.map((challenge, i) => (
                        <li key={i} className="text-gray-400 text-sm flex items-start">
                          <span className="text-blue-400 mr-2">•</span>
                          {challenge}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 bg-black/50 rounded-xl p-8 backdrop-blur-sm">
            <h3 className="text-2xl font-bold mb-4 text-blue-300">The Next Frontier</h3>
            <p className="text-gray-300 mb-4">
              As we look to the future of space exploration, several transformative trends are emerging. The 
              commercialization of space is accelerating, with private companies taking on roles traditionally 
              reserved for government agencies. This shift is driving innovation and reducing costs, making space 
              more accessible than ever before.
            </p>
            <p className="text-gray-300 mb-4">
              International cooperation continues to be essential, with collaborative projects like the Artemis 
              Accords establishing frameworks for peaceful exploration. At the same time, new spacefaring nations 
              are emerging, creating a more diverse and competitive environment.
            </p>
            <p className="text-gray-300">
              Perhaps most exciting is the prospect of establishing a permanent human presence beyond Earth. From 
              lunar bases to Martian colonies, the coming decades may see humanity become a truly multi-planetary 
              species. These endeavors will require solving immense technical challenges, from radiation protection 
              to sustainable life support systems, but the potential rewards—scientific discovery, resource utilization, 
              and the expansion of human civilization—are equally immense.
            </p>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-12 px-4 bg-black/50">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">© 2025 Cosmic Explorer | Interactive Space Exploration Website</p>
          <p className="text-gray-500 text-sm mt-2">Developed with Next.js and TailwindCSS</p>
        </div>
      </footer>
    </main>
  )
}
