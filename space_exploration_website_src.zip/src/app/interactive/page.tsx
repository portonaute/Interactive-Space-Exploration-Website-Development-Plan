'use client'

import { useEffect } from 'react'
import Navbar from '@/components/navigation/Navbar'
import Dashboard from '@/components/interactive/Dashboard'

export default function Interactive() {
  // Force dark mode
  useEffect(() => {
    document.documentElement.classList.add('dark')
  }, [])

  return (
    <main className="stars-bg min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="space-title">Interactive Dashboard</h1>
          <p className="space-subtitle max-w-3xl mx-auto">
            Explore space through our interactive simulations and visualizations.
          </p>
        </div>
      </section>
      
      {/* Interactive Dashboard */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <Dashboard />
        </div>
      </section>
      
      {/* Feature Descriptions */}
      <section className="py-16 px-4 bg-black/30">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300 text-center">Interactive Features</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-blue-300">🛰️ Satellite Orbit Viewer</h3>
              <p className="text-gray-300 mb-4">
                Visualize how satellites orbit Earth at different altitudes and inclinations. Adjust the parameters 
                to see how they affect the satellite's trajectory and speed.
              </p>
              <p className="text-gray-300">
                This simulation demonstrates concepts like orbital mechanics, Low Earth Orbit (LEO), and how 
                inclination affects a satellite's coverage area. The visualization shows a simplified model 
                of Earth and a satellite with an adjustable orbit.
              </p>
            </div>
            
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-red-300">🚀 Mars Rover Simulator</h3>
              <p className="text-gray-300 mb-4">
                Control a virtual rover on the Martian surface. Use the directional buttons to navigate the 
                rover across the simulated Martian terrain, complete with craters and rocks.
              </p>
              <p className="text-gray-300">
                This interactive feature gives you a sense of what it's like to operate a rover on Mars, similar 
                to how NASA engineers control rovers like Curiosity and Perseverance. The simulation includes a 
                simplified representation of the Martian landscape.
              </p>
            </div>
            
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-indigo-300">🏢 ISS Virtual Tour</h3>
              <p className="text-gray-300 mb-4">
                Explore the International Space Station by navigating between its various modules. Learn about 
                each module's purpose and how they connect to form the complete space station.
              </p>
              <p className="text-gray-300">
                This virtual tour allows you to move through the ISS by clicking on connected modules. Each module 
                includes information about its function, when it was added to the station, and which space agency 
                contributed it. The tour gives you a sense of the station's layout and the international cooperation 
                that made it possible.
              </p>
            </div>
            
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-purple-300">🌍 Planet Comparator</h3>
              <p className="text-gray-300 mb-4">
                Compare different features of planets in our solar system. Select up to three planets and choose 
                a comparison type to see how they stack up against each other.
              </p>
              <p className="text-gray-300">
                This tool allows you to compare planetary characteristics like size, distance from the Sun, day length, 
                year length, surface gravity, temperature, and number of moons. The visual comparison helps illustrate 
                the vast differences between planets in our solar system.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-12 px-4 bg-black/50">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">© 2025 Cosmic Explorer | Interactive Space Exploration Website</p>
          <p className="text-gray-500 text-sm mt-2">Developed with Next.js and TailwindCSS</p>
        </div>
      </footer>
    </main>
  )
}
