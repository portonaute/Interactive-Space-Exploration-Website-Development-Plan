'use client'

import { useEffect } from 'react'
import Link from '@/components/ui/link'
import Navbar from '@/components/navigation/Navbar'
import PlanetOrbit from '@/components/animations/PlanetOrbit'

export default function Home() {
  // Force dark mode
  useEffect(() => {
    document.documentElement.classList.add('dark')
  }, [])

  return (
    <main className="stars-bg min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4" aria-labelledby="hero-heading">
        <div className="container mx-auto text-center">
          <h1 id="hero-heading" className="space-title">Explore The Cosmos</h1>
          <p className="space-subtitle max-w-3xl mx-auto">
            Journey through our solar system, discover the history of space exploration, 
            and learn about cutting-edge space technology.
          </p>
          
          <div className="mt-12 relative">
            <div className="absolute inset-0 bg-blue-500/10 blur-3xl rounded-full" aria-hidden="true"></div>
            <div className="relative grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
              <Link href="/solar-system" className="nav-button">
                Solar System
              </Link>
              <Link href="/history" className="nav-button">
                Space History
              </Link>
              <Link href="/space-race" className="nav-button">
                US-Soviet Space Race
              </Link>
              <Link href="/modern-space" className="nav-button">
                Modern Space Tech
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Introduction Section */}
      <section className="py-20 px-4" aria-labelledby="intro-heading">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 id="intro-heading" className="text-3xl font-bold mb-6 text-blue-300">Our Cosmic Neighborhood</h2>
              <p className="text-gray-300 mb-4">
                The solar system consists of the Sun and everything that orbits around it, 
                including planets, dwarf planets, moons, asteroids, comets, and meteoroids. 
                For thousands of years, humanity has gazed at the stars, but only in the last 
                century have we begun to truly explore beyond our home planet.
              </p>
              <p className="text-gray-300">
                From the scorching heat of Mercury to the icy depths of the Kuiper Belt, 
                our solar system is filled with wonders waiting to be discovered. Each planet 
                has its own unique characteristics, from the violent storms of Jupiter to the 
                beautiful rings of Saturn.
              </p>
              <div className="mt-8">
                <Link href="/solar-system" className="nav-button inline-block">
                  Explore Planets
                </Link>
              </div>
            </div>
            <div className="relative" aria-hidden="true">
              <PlanetOrbit />
            </div>
          </div>
        </div>
      </section>
      
      {/* Space Exploration History Teaser */}
      <section className="py-20 px-4 bg-black/30" aria-labelledby="history-heading">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="relative h-80 w-full rounded-xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-900/50 to-purple-900/50" aria-hidden="true"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-5xl font-bold mb-2">1957</div>
                    <div className="text-xl">Sputnik 1</div>
                    <div className="mt-6 text-5xl font-bold mb-2">1969</div>
                    <div className="text-xl">Apollo 11 Moon Landing</div>
                    <div className="mt-6 text-5xl font-bold mb-2">2021</div>
                    <div className="text-xl">Mars Perseverance Rover</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <h2 id="history-heading" className="text-3xl font-bold mb-6 text-blue-300">The Journey to the Stars</h2>
              <p className="text-gray-300 mb-4">
                Humanity's journey to space began with ancient astronomers observing the night sky. 
                From Galileo's telescope to the launch of Sputnik 1, the first artificial satellite, 
                our quest to explore beyond Earth has been marked by incredible achievements and 
                technological breakthroughs.
              </p>
              <p className="text-gray-300">
                The space race between the United States and Soviet Union pushed the boundaries 
                of what was possible, culminating in the historic Apollo 11 mission that landed 
                humans on the Moon. Today, international cooperation and private companies are 
                leading a new era of space exploration.
              </p>
              <div className="mt-8">
                <Link href="/history" className="nav-button inline-block">
                  Discover History
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Interactive Features Preview */}
      <section className="py-20 px-4" aria-labelledby="interactive-heading">
        <div className="container mx-auto text-center">
          <h2 id="interactive-heading" className="text-3xl font-bold mb-6 text-blue-300">Interactive Experiences</h2>
          <p className="text-gray-300 mb-12 max-w-3xl mx-auto">
            Engage with our interactive features to deepen your understanding of space exploration. 
            From satellite orbit visualization to Mars rover simulation, these tools bring the 
            wonders of space to your fingertips.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="planet-card bg-blue-900/20 p-6">
              <div className="text-blue-300 text-4xl mb-4" aria-hidden="true">🛰️</div>
              <h3 className="text-xl font-bold mb-2">Satellite Orbit Viewer</h3>
              <p className="text-gray-400 text-sm">Visualize and adjust satellite trajectories around Earth</p>
            </div>
            
            <div className="planet-card bg-red-900/20 p-6">
              <div className="text-red-300 text-4xl mb-4" aria-hidden="true">🚀</div>
              <h3 className="text-xl font-bold mb-2">Mars Rover Simulator</h3>
              <p className="text-gray-400 text-sm">Drive a virtual rover on Mars-like terrain</p>
            </div>
            
            <div className="planet-card bg-indigo-900/20 p-6">
              <div className="text-indigo-300 text-4xl mb-4" aria-hidden="true">🏢</div>
              <h3 className="text-xl font-bold mb-2">ISS Virtual Tour</h3>
              <p className="text-gray-400 text-sm">Navigate a 3D model of the International Space Station</p>
            </div>
            
            <div className="planet-card bg-purple-900/20 p-6">
              <div className="text-purple-300 text-4xl mb-4" aria-hidden="true">🌍</div>
              <h3 className="text-xl font-bold mb-2">Planet Comparator</h3>
              <p className="text-gray-400 text-sm">Compare planetary features like size and composition</p>
            </div>
          </div>
          
          <div className="mt-8">
            <Link href="/interactive" className="nav-button inline-block">
              Try Interactive Features
            </Link>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-12 px-4 bg-black/50">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">© 2025 Cosmic Explorer | Interactive Space Exploration Website</p>
          <p className="text-gray-500 text-sm mt-2">Developed with Next.js and TailwindCSS</p>
        </div>
      </footer>
    </main>
  )
}
