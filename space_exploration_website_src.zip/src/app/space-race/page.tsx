'use client'

import { useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/navigation/Navbar'

export default function SpaceRace() {
  // Force dark mode
  useEffect(() => {
    document.documentElement.classList.add('dark')
  }, [])

  const keyEvents = [
    {
      year: '1957',
      event: 'Sputnik 1',
      country: 'USSR',
      description: 'The Soviet Union launches Sputnik 1, the world\'s first artificial satellite, shocking the United States and starting the Space Race.',
      significance: 'Demonstrated Soviet technological capabilities and triggered the formation of NASA in the United States.'
    },
    {
      year: '1957',
      event: 'Sputnik 2',
      country: 'USSR',
      description: 'The Soviet Union launches Sputnik 2 carrying Laika, the first animal to orbit Earth.',
      significance: 'Proved that living organisms could survive in space, paving the way for human spaceflight.'
    },
    {
      year: '1958',
      event: 'Explorer 1',
      country: 'USA',
      description: 'The United States launches Explorer 1, its first satellite, which discovers the Van Allen radiation belts.',
      significance: 'America\'s first successful entry into the Space Race and an important scientific discovery.'
    },
    {
      year: '1958',
      event: 'NASA Established',
      country: 'USA',
      description: 'The National Aeronautics and Space Administration (NASA) is created in response to the Soviet space achievements.',
      significance: 'Centralized American space efforts under civilian control, focusing on both military and scientific objectives.'
    },
    {
      year: '1961',
      event: 'Vostok 1',
      country: 'USSR',
      description: 'Yuri Gagarin becomes the first human in space, completing one orbit around Earth in Vostok 1.',
      significance: 'Major Soviet achievement that demonstrated the capability for human spaceflight.'
    },
    {
      year: '1961',
      event: 'Mercury-Redstone 3',
      country: 'USA',
      description: 'Alan Shepard becomes the first American in space on a suborbital flight.',
      significance: 'Though not an orbital flight like Gagarin\'s, it was an important milestone for the American space program.'
    },
    {
      year: '1962',
      event: 'Mercury-Atlas 6',
      country: 'USA',
      description: 'John Glenn becomes the first American to orbit Earth, circling the planet three times.',
      significance: 'Boosted American morale and narrowed the perceived gap with Soviet achievements.'
    },
    {
      year: '1963',
      event: 'Vostok 6',
      country: 'USSR',
      description: 'Valentina Tereshkova becomes the first woman in space.',
      significance: 'Highlighted the Soviet commitment to gender equality in space, a feat not matched by the U.S. until 1983.'
    },
    {
      year: '1965',
      event: 'Voskhod 2',
      country: 'USSR',
      description: 'Alexei Leonov conducts the first spacewalk, spending 12 minutes outside his spacecraft.',
      significance: 'Demonstrated the feasibility of extravehicular activity, crucial for future space operations.'
    },
    {
      year: '1968',
      event: 'Apollo 8',
      country: 'USA',
      description: 'First crewed mission to orbit the Moon, with astronauts Frank Borman, James Lovell, and William Anders.',
      significance: 'Marked a turning point in the Space Race as the U.S. took the lead in lunar exploration.'
    },
    {
      year: '1969',
      event: 'Apollo 11',
      country: 'USA',
      description: 'Neil Armstrong and Buzz Aldrin become the first humans to walk on the Moon.',
      significance: 'Fulfilled President Kennedy\'s goal and effectively ended the Space Race with an American victory.'
    },
    {
      year: '1971',
      event: 'Salyut 1',
      country: 'USSR',
      description: 'The Soviet Union launches Salyut 1, the world\'s first space station.',
      significance: 'Shifted Soviet focus to long-duration spaceflight after losing the race to the Moon.'
    },
    {
      year: '1975',
      event: 'Apollo-Soyuz Test Project',
      country: 'USA/USSR',
      description: 'American Apollo and Soviet Soyuz spacecraft dock in orbit in a symbol of détente.',
      significance: 'Marked the symbolic end of the Space Race and the beginning of international cooperation in space.'
    }
  ]

  return (
    <main className="stars-bg min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="space-title">The US-Soviet Space Race</h1>
          <p className="space-subtitle max-w-3xl mx-auto">
            A Cold War competition that pushed the boundaries of human achievement and shaped the future of space exploration.
          </p>
        </div>
      </section>
      
      {/* Historical Context */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300">Historical Context</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-black/30 rounded-xl p-8 backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-4 text-red-300">Cold War Tensions</h3>
              <p className="text-gray-300 mb-4">
                The Space Race emerged from the geopolitical tensions between the United States and the Soviet Union 
                following World War II. As the two superpowers engaged in a broader Cold War, space became a crucial 
                arena for demonstrating technological superiority, military capability, and ideological dominance.
              </p>
              <p className="text-gray-300 mb-4">
                The launch of Sputnik 1 in 1957 came as a shock to the American public and government, creating fears 
                of a "missile gap" and raising concerns about Soviet technological capabilities. The satellite's launch 
                demonstrated that the Soviet Union could potentially deliver nuclear weapons to American soil using the 
                same rocket technology.
              </p>
              <p className="text-gray-300">
                This perceived threat accelerated American efforts in space, leading to the creation of NASA in 1958 
                and increased funding for science and technology education. The Space Race became a proxy for the 
                broader ideological struggle between capitalism and communism, with each success serving as propaganda 
                for the respective political systems.
              </p>
            </div>
            
            <div className="bg-black/30 rounded-xl p-8 backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-4 text-blue-300">Political Significance</h3>
              <p className="text-gray-300 mb-4">
                For both nations, the Space Race was as much about prestige and soft power as it was about scientific 
                advancement. Soviet Premier Nikita Khrushchev used early space achievements to promote the superiority 
                of the communist system, while American presidents from Eisenhower to Nixon emphasized space exploration 
                as a demonstration of American ingenuity and freedom.
              </p>
              <p className="text-gray-300 mb-4">
                President John F. Kennedy's 1961 speech committing the United States to landing a man on the Moon "before 
                this decade is out" transformed the Space Race into a clear, public competition with a defined goal. This 
                national commitment mobilized American resources and talent toward a single objective, resulting in one of 
                the greatest technological achievements in human history.
              </p>
              <p className="text-gray-300">
                The political nature of the Space Race also influenced mission selection and timing, with both nations 
                sometimes prioritizing spectacular achievements over scientific value. Despite this competition, the Space 
                Race ultimately led to significant scientific and technological advancements that benefited humanity as a whole.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Key Events Timeline */}
      <section className="py-16 px-4 bg-black/30">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300 text-center">Key Events</h2>
          
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-[15px] md:left-1/2 top-0 bottom-0 w-1 bg-blue-500/30 transform md:translate-x-[-50%]"></div>
            
            {/* Events */}
            <div className="space-y-12">
              {keyEvents.map((event, index) => (
                <div key={index} className={`relative flex flex-col md:flex-row gap-8 ${
                  event.country === 'USSR' ? 'md:flex-row-reverse' : ''
                }`}>
                  {/* Timeline Dot */}
                  <div className={`absolute left-[7px] md:left-1/2 top-0 w-4 h-4 rounded-full transform md:translate-x-[-50%] z-10 ${
                    event.country === 'USSR' ? 'bg-red-500' : 
                    event.country === 'USA' ? 'bg-blue-500' : 'bg-purple-500'
                  }`}></div>
                  
                  {/* Year */}
                  <div className="md:w-1/2 pl-10 md:pl-0 flex md:justify-end items-start">
                    <div className={`px-4 py-2 rounded-lg ${
                      event.country === 'USSR' ? 'bg-red-900/30' : 
                      event.country === 'USA' ? 'bg-blue-900/30' : 'bg-purple-900/30'
                    }`}>
                      <span className="text-xl font-bold">{event.year}</span>
                      <span className="ml-2 text-sm font-medium">{event.country}</span>
                    </div>
                  </div>
                  
                  {/* Content */}
                  <div className="md:w-1/2 bg-black/50 p-6 rounded-xl backdrop-blur-sm ml-10 md:ml-0">
                    <h3 className="text-xl font-bold mb-2 text-white">{event.event}</h3>
                    <p className="text-gray-300 mb-3">{event.description}</p>
                    <p className="text-sm text-blue-200 italic">Significance: {event.significance}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Modern Influence */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-blue-300">Modern Influence</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-green-300">Technological Legacy</h3>
              <p className="text-gray-300 mb-4">
                The intense competition of the Space Race accelerated technological development in numerous fields. 
                Advances in rocketry, materials science, computing, telecommunications, and miniaturization were 
                driven by the needs of space programs and later found applications in everyday life.
              </p>
              <p className="text-gray-300">
                Technologies developed or improved during the Space Race include integrated circuits, satellite 
                communications, weather forecasting, solar panels, water purification systems, and numerous medical 
                innovations. The modern digital age owes much to the computing advances necessitated by spaceflight.
              </p>
            </div>
            
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-yellow-300">International Cooperation</h3>
              <p className="text-gray-300 mb-4">
                While the Space Race was characterized by competition, it eventually gave way to cooperation. 
                The Apollo-Soyuz Test Project in 1975 symbolized this shift, as American and Soviet spacecraft 
                docked in orbit for the first time.
              </p>
              <p className="text-gray-300">
                This spirit of cooperation continued with the Shuttle-Mir program in the 1990s and culminated in 
                the International Space Station, a joint project involving the United States, Russia, Europe, Japan, 
                and Canada. Today, international collaboration is the norm in space exploration, with agencies sharing 
                costs, expertise, and data.
              </p>
            </div>
            
            <div className="bg-black/50 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 text-purple-300">Cultural Impact</h3>
              <p className="text-gray-300 mb-4">
                The Space Race captured the public imagination and influenced popular culture in profound ways. 
                Space-themed entertainment, from Stanley Kubrick's "2001: A Space Odyssey" to Star Trek, reflected 
                and shaped public perceptions of space exploration.
              </p>
              <p className="text-gray-300">
                The iconic images from the Space Race era, such as Earthrise from Apollo 8 and Neil Armstrong's 
                first steps on the Moon, changed humanity's perspective of our planet and our place in the universe. 
                The environmental movement was partly inspired by these images of Earth as a fragile blue marble in 
                the vastness of space.
              </p>
            </div>
          </div>
          
          <div className="mt-12 bg-black/30 rounded-xl p-8 backdrop-blur-sm">
            <h3 className="text-2xl font-bold mb-4 text-blue-300">From Competition to Commercialization</h3>
            <p className="text-gray-300 mb-4">
              Perhaps the most significant modern legacy of the Space Race is the emergence of commercial spaceflight. 
              The technologies and expertise developed during this era laid the groundwork for private companies like 
              SpaceX, Blue Origin, and Virgin Galactic to enter the space sector.
            </p>
            <p className="text-gray-300 mb-4">
              These companies are building upon the foundation established during the Space Race, developing reusable 
              rockets, planning lunar missions, and even setting their sights on Mars. The commercialization of space 
              has reduced costs, increased access to orbit, and opened new possibilities for scientific research, 
              telecommunications, and even space tourism.
            </p>
            <p className="text-gray-300">
              As we enter this new era of space exploration, the lessons and achievements of the Space Race continue 
              to influence our approach to the final frontier. The spirit of innovation, the value of national commitment 
              to ambitious goals, and the potential for both competition and cooperation to drive progress remain relevant 
              today.
            </p>
            <div className="mt-6">
              <Link href="/modern-space" className="nav-button inline-block">
                Explore Modern Space Technology
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-12 px-4 bg-black/50">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">© 2025 Cosmic Explorer | Interactive Space Exploration Website</p>
          <p className="text-gray-500 text-sm mt-2">Developed with Next.js and TailwindCSS</p>
        </div>
      </footer>
    </main>
  )
}
